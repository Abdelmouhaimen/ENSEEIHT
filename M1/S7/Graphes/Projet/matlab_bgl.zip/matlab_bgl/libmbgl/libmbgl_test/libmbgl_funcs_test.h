extern const char* errstr;
int planar_funcs_test();
int layout_funcs_test();

